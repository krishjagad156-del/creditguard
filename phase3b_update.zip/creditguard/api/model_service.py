"""Loads the trained pipeline ONCE and turns validated input into a prediction."""
from __future__ import annotations

import json
from pathlib import Path

import joblib
import pandas as pd

from creditguard import __version__, config


class ModelNotLoadedError(RuntimeError):
    pass


class ModelService:
    def __init__(self, model_path: Path, meta_path: Path):
        self.model_path = Path(model_path)
        self.meta_path = Path(meta_path)
        self.model = None
        self.meta: dict = {}

    @property
    def loaded(self) -> bool:
        return self.model is not None

    def load(self) -> None:
        if not (self.model_path.exists() and self.meta_path.exists()):
            return  # stay "not loaded"; /health reports degraded, /predict returns 503
        self.model = joblib.load(self.model_path)
        self.meta = json.loads(self.meta_path.read_text())

    @property
    def version(self) -> str:
        return f"{__version__}+{self.meta.get('selected_model', 'unknown')}"

    @property
    def threshold(self) -> float:
        return float(self.meta["threshold"])

    def predict(self, features: dict, threshold: float | None = None) -> dict:
        if not self.loaded:
            raise ModelNotLoadedError("Model artifacts are not available.")
        row = pd.DataFrame([features], columns=config.INPUT_COLUMNS)
        prob = float(self.model.predict_proba(row)[0, 1])
        t = self.threshold if threshold is None else float(threshold)
        band = "High" if prob >= t else ("Medium" if prob >= t / 2 else "Low")
        return {
            "default_probability": prob,
            "risk_band": band,
            "flagged_for_review": prob >= t,
            "threshold": t,
            "model_version": self.version,
        }
